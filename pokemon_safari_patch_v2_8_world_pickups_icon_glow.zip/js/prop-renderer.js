(function () {
  const NS = window.SafariGame = window.SafariGame || {};

  const images = {};
  const pickupImages = {};
  const PICKUP_ART = {
    stonePickup: 'assets/pickups/stone-pile.png',
    baitPickup: 'assets/pickups/bait-bag.png',
  };

  function imageFor(atlasId) {
    if(images[atlasId]) return images[atlasId];
    const url=NS.PROP_ATLASES?.[atlasId];
    if(!url) return null;
    const img=new Image();
    img.src=url;
    img.decoding='async';
    images[atlasId]=img;
    return img;
  }


  function pickupImageFor(type) {
    if(pickupImages[type]) return pickupImages[type];
    const url=PICKUP_ART[type];
    if(!url) return null;
    const img=new Image();
    img.src=url;
    img.decoding='async';
    pickupImages[type]=img;
    return img;
  }

  function frameFor(type,variant=0) {
    const list=NS.PROP_ATLAS_FRAMES?.[type];
    if(!list?.length) return null;
    return list[Math.abs(variant|0)%list.length];
  }

  function drawAtlasProp(ctx,type,variant,x,y,meta) {
    const frame=frameFor(type,variant);
    if(!frame) return false;
    const img=imageFor(frame.atlas);
    if(!img || !img.complete || img.naturalWidth===0) return false;

    ctx.save();
    ctx.imageSmoothingEnabled=false;
    ctx.drawImage(
      img,
      frame.x,frame.y,frame.w,frame.h,
      Math.round(x-meta.drawW/2),
      Math.round(y-meta.drawH),
      meta.drawW,
      meta.drawH
    );
    ctx.restore();
    return true;
  }

  function drawPlaceholder(ctx,x,y,meta,type) {
    ctx.save();
    ctx.imageSmoothingEnabled=false;
    ctx.fillStyle=type.includes('Tree')||type==='charredTree'||type==='twistedTree'?'#486b46':'#6e756f';
    ctx.fillRect(Math.round(x-meta.drawW*.25),Math.round(y-meta.drawH*.45),Math.max(4,Math.round(meta.drawW*.5)),Math.max(4,Math.round(meta.drawH*.4)));
    ctx.restore();
  }

  function drawSpecialMarker(ctx,o,x,y) {
    if(!o.special||o.used) return;
    const iy=y-(o.markerOffset||36);
    ctx.save();
    ctx.fillStyle='rgba(18,28,21,.90)';
    ctx.beginPath(); ctx.arc(x,iy,12,0,Math.PI*2); ctx.fill();
    ctx.strokeStyle='#f4dd67'; ctx.lineWidth=2; ctx.stroke();
    ctx.fillStyle='#f7e67b'; ctx.font='15px "m6x11", monospace';
    ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText('!',x,iy+1);
    ctx.restore();
  }

  function drawPickupGlow(ctx,x,y,pulse) {
    ctx.save();
    ctx.imageSmoothingEnabled=false;

    // Halo brillante tipo destello detrás del icono.
    const flareAlpha=0.28 + 0.18 * pulse;
    ctx.strokeStyle=`rgba(255,255,255,${0.34 + 0.20 * pulse})`;
    ctx.lineWidth=1.2;
    ctx.beginPath();
    ctx.arc(x, y, 10 + pulse * 2, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle=`rgba(255,255,255,${flareAlpha})`;
    ctx.lineWidth=2;
    const rays=[[0,-13,0,13],[-13,0,13,0],[-9,-9,9,9],[-9,9,9,-9]];
    for(const [x1,y1,x2,y2] of rays){
      ctx.beginPath();
      ctx.moveTo(x+x1,y+y1);
      ctx.lineTo(x+x2,y+y2);
      ctx.stroke();
    }

    // Resalte dorado suave en la base.
    ctx.fillStyle=`rgba(255,218,88,${0.18 + 0.10 * pulse})`;
    ctx.beginPath();
    ctx.ellipse(x, y + 7, 13 + pulse, 6 + pulse * .4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawStonePickupIcon(ctx,x,y) {
    // Pequeño montón de rocas, similar a icono de herramienta.
    ctx.save();
    ctx.imageSmoothingEnabled=false;
    ctx.fillStyle='#5d6672';
    ctx.fillRect(x-7,y+1,6,4);
    ctx.fillRect(x-1,y,5,5);
    ctx.fillRect(x+3,y+2,5,3);
    ctx.fillStyle='#8d97a4';
    ctx.fillRect(x-6,y+1,3,2);
    ctx.fillRect(x,y,2,2);
    ctx.fillRect(x+4,y+2,2,1);
    ctx.strokeStyle='#2d3138';
    ctx.lineWidth=1;
    ctx.strokeRect(x-7.5,y+.5,6,4);
    ctx.strokeRect(x-.5,y-.5,5,5);
    ctx.strokeRect(x+2.5,y+1.5,5,3);
    ctx.restore();
  }

  function drawBaitPickupIcon(ctx,x,y) {
    // Bola de cebo marrón, similar al icono de herramienta seleccionado.
    ctx.save();
    ctx.imageSmoothingEnabled=false;
    ctx.fillStyle='#8b5a2b';
    ctx.beginPath();
    ctx.arc(x, y+2, 5.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle='#c88b4a';
    ctx.beginPath();
    ctx.arc(x-1.5, y+0.5, 2.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle='#5d3919';
    ctx.lineWidth=1;
    ctx.beginPath();
    ctx.arc(x, y+2, 5.5, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  function drawPickup(ctx,o,x,y) {
    if(o.used) return true;

    const t=performance.now();
    const pulse=.5+.5*Math.sin(t*.008+(o.x+o.y)*.014);
    const isStone=o.type==='stonePickup';

    // El objeto se apoya en el suelo, sin flotar.
    const groundY=Math.round(y+1);
    const iconX=Math.round(x);
    const iconY=isStone ? Math.round(groundY-9) : Math.round(groundY-10);

    ctx.save();
    ctx.imageSmoothingEnabled=false;

    // Sombra pequeña en el suelo.
    ctx.fillStyle='rgba(18,24,21,.24)';
    ctx.beginPath();
    ctx.ellipse(iconX, groundY+2, isStone ? 8 : 7, 3, 0, 0, Math.PI*2);
    ctx.fill();

    // Brillo tipo destello alrededor del icono.
    drawPickupGlow(ctx, iconX, iconY, pulse);

    if(isStone) drawStonePickupIcon(ctx,iconX,iconY);
    else drawBaitPickupIcon(ctx,iconX,iconY);

    ctx.restore();
    return true;
  }


  function drawObject(ctx,o,camera,w,h) {
    const camX=Math.floor(camera.x);
    const camY=Math.floor(camera.y);
    const x=Math.floor(o.x-camX+w/2);
    const y=Math.floor(o.y-camY+h/2);

    if(o.type==='stonePickup'||o.type==='baitPickup') return drawPickup(ctx,o,x,y);

    if(o.type==='waterSpot') {
      ctx.save();
      ctx.fillStyle=o.used?'rgba(39,91,116,.18)':'rgba(24,71,100,.48)';
      ctx.beginPath(); ctx.ellipse(x,y-4,25,13,0,0,Math.PI*2); ctx.fill();
      ctx.strokeStyle='rgba(205,244,246,.62)'; ctx.lineWidth=2;
      ctx.beginPath(); ctx.ellipse(x,y-4,17,8,0,0,Math.PI*2); ctx.stroke();
      ctx.restore();
      drawSpecialMarker(ctx,o,x,y);
      return true;
    }

    const type=o.visualType;
    const meta=NS.PROP_VISUAL_META[type];
    if(!type||!meta) return false;

    if(!drawAtlasProp(ctx,type,o.variant||0,x,y,meta)) {
      drawPlaceholder(ctx,x,y,meta,type);
    }

    drawSpecialMarker(ctx,o,x,y);
    return true;
  }

  // Iniciamos las cargas sin bloquear el arranque. El dibujo usa cada PNG en cuanto termina.
  for(const atlasId of Object.keys(NS.PROP_ATLASES||{})) imageFor(atlasId);
  for(const pickupType of Object.keys(PICKUP_ART)) pickupImageFor(pickupType);

  NS.PropRenderer={drawObject,images,frameFor};
  console.info('[Pokémon Safari] Renderer multi-atlas V2.8.3: pickups del mundo con icono de herramienta y destello brillante.');
})();
